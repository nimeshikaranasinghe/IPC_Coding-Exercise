Author: Nimeshika Ranasinghe

SalarySlipGenerator => Source code of the script
Sample_CSV_Files => Sample CSV files used to test
Sample_CSV_Files => HTML files generated thorugh the script run
	1. nimeshikar.html => sample employee salary slip
	2. SalaryReport_201902.html => Salary report sent to the manager

Salary_Slip_Generator_User_Guide => Usage of the tool

LiveOps.pptx => Presenation including requested details